// Package handlers provides HTTP request handlers for the presentation layer.
package handlers

import (
	"net/http"
	"strconv"
	"strings"

	"github.com/AtRiskMedia/tractstack-go/internal/application/services"
	"github.com/AtRiskMedia/tractstack-go/internal/domain/events"
	"github.com/AtRiskMedia/tractstack-go/internal/infrastructure/messaging"
	"github.com/AtRiskMedia/tractstack-go/internal/infrastructure/observability/logging"
	"github.com/AtRiskMedia/tractstack-go/internal/infrastructure/observability/performance"
	"github.com/AtRiskMedia/tractstack-go/internal/presentation/http/middleware"
	"github.com/gin-gonic/gin"
)

// StateHandlers contains all state-related HTTP handlers with SSE broadcasting support
type StateHandlers struct {
	eventProcessor *services.EventProcessingService
	broadcaster    messaging.Broadcaster
	logger         *logging.ChanneledLogger
	perfTracker    *performance.Tracker
}

// NewStateHandlers creates state handlers with injected dependencies including broadcaster
func NewStateHandlers(
	eventProcessor *services.EventProcessingService,
	broadcaster messaging.Broadcaster,
	logger *logging.ChanneledLogger,
	perfTracker *performance.Tracker,
) *StateHandlers {
	return &StateHandlers{
		eventProcessor: eventProcessor,
		broadcaster:    broadcaster,
		logger:         logger,
		perfTracker:    perfTracker,
	}
}

// PostState handles POST /api/v1/state - processes widget state updates and belief events with SSE broadcasting
func (h *StateHandlers) PostState(c *gin.Context) {
	tenantCtx, exists := middleware.GetTenantContext(c)
	if !exists {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "tenant context not found"})
		return
	}

	marker := h.perfTracker.StartOperation("post_state_request", tenantCtx.TenantID)
	defer marker.Complete()

	sessionID := c.GetHeader("X-TractStack-Session-ID")
	if sessionID == "" {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Session ID required"})
		return
	}

	storyFragmentID := c.GetHeader("X-StoryFragment-ID")
	h.logger.System().Debug("UNSET DEBUG: Headers received",
		"sessionId", sessionID,
		"storyFragmentId", storyFragmentID,
		"tenantId", tenantCtx.TenantID)

	var eventList []events.Event
	var paneID, gotoPaneID string

	// Handle bulk unset first, as it's a distinct form payload
	if unsetBeliefIds := c.PostForm("unsetBeliefIds"); unsetBeliefIds != "" {
		beliefIDs := strings.Split(unsetBeliefIds, ",")
		for _, beliefID := range beliefIDs {
			beliefID = strings.TrimSpace(beliefID)
			if beliefID != "" {
				eventList = append(eventList, events.Event{
					ID:     beliefID,
					Type:   "Belief",
					Verb:   "UNSET",
					Object: beliefID,
				})
			}
		}
		paneID = c.PostForm("paneId")
		gotoPaneID = c.PostForm("gotoPaneID")
	} else { // Handle single belief or action event
		var req struct {
			BeliefID     string `form:"beliefId"`
			BeliefType   string `form:"beliefType"`
			BeliefValue  string `form:"beliefValue"`
			BeliefObject string `form:"beliefObject"`
			Duration     int    `form:"duration"`
		}
		if err := c.ShouldBind(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid form data"})
			return
		}

		if req.BeliefID == "" || req.BeliefType == "" {
			c.JSON(http.StatusBadRequest, gin.H{"error": "beliefId and beliefType are required"})
			return
		}
		eventList = append(eventList, convertRequestToEvent(&req))
		paneID = c.PostForm("paneId")
	}

	if unsetBeliefIds := c.PostForm("unsetBeliefIds"); unsetBeliefIds != "" {
		h.logger.System().Debug("UNSET DEBUG: Processing UNSET request",
			"unsetBeliefIds", unsetBeliefIds,
			"storyFragmentId", storyFragmentID,
			"eventCount", len(eventList))
	}
	h.logger.System().Debug("UNSET DEBUG: Calling ProcessEventsWithSSE",
		"sessionId", sessionID,
		"storyFragmentId", storyFragmentID,
		"eventCount", len(eventList))

	if err := h.eventProcessor.ProcessEventsWithSSE(tenantCtx, sessionID, storyFragmentID, eventList, paneID, gotoPaneID, h.broadcaster); err != nil {
		h.logger.System().Error("State processing failed", "error", err, "tenantId", tenantCtx.TenantID)
		marker.SetError(err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Event processing failed"})
		return
	}

	marker.SetSuccess(true)
	h.logger.Perf().Info("Performance for PostState request", "duration", marker.Duration, "tenantId", tenantCtx.TenantID, "success", true)

	c.JSON(http.StatusOK, gin.H{"status": "ok", "tenantId": tenantCtx.TenantID})
}

// convertRequestToEvent converts form data into a domain event.
func convertRequestToEvent(req *struct {
	BeliefID     string `form:"beliefId"`
	BeliefType   string `form:"beliefType"`
	BeliefValue  string `form:"beliefValue"`
	BeliefObject string `form:"beliefObject"`
	Duration     int    `form:"duration"`
},
) events.Event {
	// Handle Pane and StoryFragment Action Events (like READ, GLOSSED, PAGEVIEWED)
	if req.BeliefType == "Pane" || req.BeliefType == "StoryFragment" {
		event := events.Event{
			ID:     req.BeliefID,
			Type:   req.BeliefType,
			Verb:   req.BeliefValue,
			Object: strconv.Itoa(req.Duration),
		}
		return event
	}

	// Handle Belief Events (existing logic)
	if req.BeliefObject != "" {
		event := events.Event{
			ID:     req.BeliefID,
			Type:   req.BeliefType,
			Verb:   "IDENTIFY_AS",
			Object: req.BeliefObject,
		}
		return event
	}
	if req.BeliefValue != "" && req.BeliefValue != "0" {
		event := events.Event{
			ID:     req.BeliefID,
			Type:   req.BeliefType,
			Verb:   req.BeliefValue,
			Object: req.BeliefID,
		}
		return event
	}
	event := events.Event{
		ID:     req.BeliefID,
		Type:   req.BeliefType,
		Verb:   "UNSET",
		Object: req.BeliefID,
	}
	return event
}
